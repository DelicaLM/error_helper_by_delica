
def check_type(expected_type, received_type, var_name, alt_type=None, prefix = ""):
    error_string = prefix
    if expected_type != received_type:
        if alt_type is not None and received_type != alt_type:
            expected_type_str = str(expected_type)
            if expected_type_str.startswith("<class '"):
                expected_type_str = expected_type_str[len("<class '"):len(expected_type_str)-2]
            received_type_str = str(received_type)
            if received_type_str.startswith("<class '"):
                received_type_str = received_type_str[len("<class '"):len(received_type_str)-2]
            error_string += "SUBMITTED TYPE: " + received_type_str
            error_string += " REQUIRED TYPE: " + expected_type_str
            error_string += "\nYou have submitted an incorrect type for " + var_name + ".\n"
            error_string += "Please provide a value of type " + expected_type_str + " for this parameter."
            raise TypeError(error_string)

def check_value(input_value, min_value, max_value, var_name, prefix=""):
    error_string = prefix
    if input_value < min_value:
        error_string += "SUBMITTED VALUE: " + str(input_value)
        error_string += " < MINIMUM VALUE: " + str(min_value)
        error_string += "The value that you have provided for " + var_name + " is too small.\n"
        error_string += "Please provide a value greater than or equal to " + min_value + ".\n"
        raise ValueError(error_string)
    elif input_value > max_value:
        error_string += "SUBMITTED VALUE: " + str(input_value)
        error_string += " > MAXIMUM VALUE: " + str(max_value)
        error_string += "The value that you have provided for " + var_name + " is too large.\n"
        error_string += "Please provide a value greater than or equal to " + max_value + ".\n"
        raise ValueError(error_string)

def check_value_is_in_set(input_value, accepted_values, var_name, prefix=""):
    error_string = prefix
    if input_value not in accepted_values:
        print(var_name)
        error_string += "SUBMITTED VALUE: " + str(input_value) + "\n"
        error_string += ("The value that you have provided for "
                         + var_name + " is not in the set of accepted values for this parameter.\n")
        error_string += " Please provide a value from the following list:\n"
        error_string += str(accepted_values)
        raise ValueError(error_string)

# def check_font_name(gui, font_name, prefix=""):
#     # Make sure that the font name is a string.
#     check_type(str, type(font_name),
#                f"the font family that should be used for the text (e.g., \"{gui.DEFAULT_FONT_NAME}\")",
#                prefix=prefix)
#     # Make sure that the GUI can support the font.
#     check_value_is_in_set(font_name, gui.get_supported_font_names(),
#                               f"the font family that should be used for the text (e.g., \"{gui.DEFAULT_FONT_NAME}\")",
#                               prefix=prefix)